﻿//priority 100
// This File has been authored by AllTheMods Staff, or a Community contributor for use in AllTheMods - AllTheMods 10: To the Sky.
// As all AllTheMods packs are licensed under All Rights Reserved, this file is not allowed to be used in any public packs not released by the AllTheMods Team, without explicit permission.

global.flux = [
  {
    clickedBlock: "minecraft:obsidian",
    baseBlock: "allthecompressed:obsidian_1x",
    inputItem: "minecraft:redstone",
    outputItem: "fluxnetworks:flux_dust",
    resultBlock: "minecraft:cobblestone"
  }
]

// This File has been authored by AllTheMods Staff, or a Community contributor for use in AllTheMods - AllTheMods 10: To the Sky.
// As all AllTheMods packs are licensed under All Rights Reserved, this file is not allowed to be used in any public packs not released by the AllTheMods Team, without explicit permission.
