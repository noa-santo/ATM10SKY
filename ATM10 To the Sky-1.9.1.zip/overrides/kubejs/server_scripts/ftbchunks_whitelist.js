ServerEvents.tags("block", (event) => {
  event.add("ftbchunks:interact_whitelist", "epitaphs:grave")
  event.add("ftbchunks:edit_whitelist", "epitaphs:grave")
})
