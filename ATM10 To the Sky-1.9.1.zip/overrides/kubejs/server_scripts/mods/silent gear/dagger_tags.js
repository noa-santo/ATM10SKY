ServerEvents.tags("item", (allthemods) => {
  allthemods.add("minecraft:enchantable/sword", "silentgear:dagger")
  allthemods.add("minecraft:enchantable/fire_aspect", "silentgear:dagger")
  allthemods.add("minecraft:enchantable/sharp_weapon", "silentgear:dagger")
  allthemods.add("minecraft:enchantable/weapon", "silentgear:dagger")
  allthemods.add("minecraft:enchantable/vanishing", "silentgear:dagger")
})
