ServerEvents.recipes((allthemods) => {
  allthemods.remove({ id: "supplementaries:faucet" })
})
